package aaf.fedreg.core

class IdentityProvider extends aaf.fedreg.saml2.metadata.orm.IDPSSODescriptor {
	
}